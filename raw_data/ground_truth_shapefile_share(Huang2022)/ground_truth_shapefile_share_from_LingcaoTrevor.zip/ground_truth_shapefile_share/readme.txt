
Boundaries of retregrossive thaw slumps across the Canadian Arctic, created by Trevor Lantz and his research group at University of Victoria.
These boundaries were delineated from PlanetScope imagery acquired in 2020. 

Please see more details in the following paper:
Huang, L., Lantz, T. C., Fraser, R. H., Tiampo, K. F., Willis, M. J., & Schaefer, K. (2022). Accuracy, Efficiency, and Transferability of a Deep Learning Model for Mapping Retrogressive Thaw Slumps across the Canadian Arctic. Remote Sensing, 14(12), 2747.



