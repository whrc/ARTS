Shape-File Metadata:
RTSID (int): unique RTS ID for each Time Period (same as in csv-file)
DateFirst (date): date of first observation to generate elevation mode (combined during winter) - for TP1 Date First can also be 2010/11 or 2012/13
DateLast (date): date of second observation to generate elevation mode (combined during winter)
ID_in_TP (int): value used to identify RTS from TP1 in TP2 

CSV-Files:
RTS_vol_area_changes_TP1
RTS_vol_area_changes_TP2
RTS_SOC_changes_TP1
RTS_SOC_changes_TP2